import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.learnova.ai',
  appName: 'LEARNOVA AI',
  webDir: 'public',
  server: {
    // For local Android testing, set this to the URL where your LEARNOVA
    // server is reachable from the phone, e.g. http://192.168.1.10:3000.
    // Do NOT ship with this local URL; use HTTPS production hosting.
    cleartext: true
  },
  android: {
    allowMixedContent: false
  }
};

export default config;

import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import fs from 'node:fs/promises';
import OpenAI from 'openai';

const app = express();
const port = process.env.PORT || 3000;
const upload = multer({
  dest: 'tmp/',
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === 'application/pdf' || file.originalname.toLowerCase().endsWith('.pdf')) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are supported.'));
    }
  }
});

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

const studyInstruction = `You are LEARNOVA AI, a patient learning assistant.
Explain clearly and accurately. When helping with schoolwork, teach the reasoning and encourage understanding rather than pretending the student did the work.
Use headings and bullet points when useful.`;

async function uploadPdfToOpenAI(localPath, filename) {
  const file = await client.files.create({
    file: await fs.open(localPath, 'r').then(handle => {
      handle.close();
      return fs.open(localPath, 'r').then(h => h.createReadStream());
    }),
    purpose: 'user_data'
  });
  return file;
}

app.post('/api/pdf/upload', upload.single('pdf'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Please choose a PDF file.' });
  if (!process.env.OPENAI_API_KEY) {
    await fs.rm(req.file.path, { force: true });
    return res.status(500).json({ error: 'AI is not configured. Add OPENAI_API_KEY to .env.' });
  }

  try {
    const file = await client.files.create({
      file: await import('node:fs').then(({ createReadStream }) => createReadStream(req.file.path)),
      purpose: 'user_data'
    });

    await fs.rm(req.file.path, { force: true });

    res.json({
      fileId: file.id,
      filename: req.file.originalname,
      message: 'PDF uploaded successfully.'
    });
  } catch (error) {
    await fs.rm(req.file.path, { force: true });
    console.error(error);
    res.status(500).json({ error: 'The PDF could not be uploaded.' });
  }
});

app.post('/api/pdf/ask', async (req, res) => {
  try {
    const { fileId, filename, question, action = 'ask' } = req.body;

    if (!fileId) return res.status(400).json({ error: 'Upload a PDF first.' });
    if (!question && action === 'ask') return res.status(400).json({ error: 'Enter a question.' });

    const prompts = {
      ask: question,
      summary: 'Summarize this PDF for a student. Give the main ideas, important terms, key facts, and a short revision checklist.',
      simple: 'Explain the most important ideas in this PDF in very simple language, as if teaching a student who is new to the topic.',
      quiz: 'Create a 10-question practice quiz based only on the contents of this PDF. Include answers at the end and cover different sections of the document.'
    };

    const response = await client.responses.create({
      model: 'gpt-5.6-luna',
      input: [
        {
          role: 'developer',
          content: `${studyInstruction}
You are working with the PDF named "${filename || 'uploaded PDF'}".
Use the PDF as the primary source. If the answer is not supported by the PDF, say so rather than inventing information.`
        },
        {
          role: 'user',
          content: [
            { type: 'input_text', text: prompts[action] || question },
            { type: 'input_file', file_id: fileId }
          ]
        }
      ]
    });

    res.json({ answer: response.output_text || 'I could not generate an answer from the PDF.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'I could not read or answer from that PDF.' });
  }
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message, mode = 'chat', history = [] } = req.body;
    if (!message || typeof message !== 'string') return res.status(400).json({ error: 'Please enter a question.' });

    const instructions = {
      chat: 'Be a helpful AI learning assistant.',
      study: 'Act as a patient tutor. Teach step-by-step with examples.',
      research: 'Act as a research assistant. Distinguish facts from uncertainty and suggest credible sources when needed.'
    };

    const safeHistory = Array.isArray(history)
      ? history.slice(-10).filter(x => x && (x.role === 'user' || x.role === 'assistant') && typeof x.content === 'string')
      : [];

    const response = await client.responses.create({
      model: 'gpt-5.6-luna',
      input: [
        { role: 'developer', content: `${studyInstruction} ${instructions[mode] || instructions.chat}` },
        ...safeHistory,
        { role: 'user', content: message }
      ]
    });

    res.json({ answer: response.output_text || 'No response.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Something went wrong while contacting the AI.' });
  }
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'PDF must be 20 MB or smaller.' : err.message });
  }
  if (err) return res.status(400).json({ error: err.message });
  res.status(500).json({ error: 'Server error.' });
});

app.listen(port, () => console.log(`LEARNOVA AI v2 running at http://localhost:${port}`));
